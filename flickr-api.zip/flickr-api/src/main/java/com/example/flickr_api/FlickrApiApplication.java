package com.example.flickr_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlickrApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlickrApiApplication.class, args);
	}

}
